@extends('layouts.app')

@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Update App Settings</h1>
</div>

@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif

<div class="container">

    <form method="POST" action="{{ route('app_settings') }}" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <label for="title" class="form-label">App Title</label>
            <input type="hidden" name='settings_key[]' value="APP_NAME">
            <input type="text" class="form-control" id="title" name='settings_val[]' value="{{ env('APP_NAME') }}">
        </div>

        <div class="mb-3">
            <label for="about_us" class="form-label">About us Link</label>
            <input type="hidden" name='settings_key[]' value="ABOUT_US_LINK">
            <input type="text" class="form-control" id="about_us" name='settings_val[]' value="{{ env('ABOUT_US_LINK') }}">
          </div>

        <div class="mb-3">
            <label for="share_link" class="form-label">App Share Link </label>
            <input type="hidden" name='settings_key[]' value="SHARE_LINK">
            <input type="text" class="form-control" id="share_link" name='settings_val[]' value="{{ env('SHARE_LINK') }}">
        </div>

        @if (env("ADMIN_LOGO") !="")
            <img class="img-fluid pl-3" width="200px" src="{{asset('/upload/')."/".env("ADMIN_LOGO")}}" alt="Admin Logo">
        @endif
        <div class="form-group mb-3">
        <label class="form-check-label col-lg-6" for="">Admin Logo</label>
            <div class="col-lg-12">
                <input type="file" class="form-control" value="{{asset('upload/').env("ADMIN_LOGO")}}" name="admin_logo">
            </div>
        </div>

        <div class="">
            <button type="submit" class="btn btn-sm btn-success">Submit</button>
        </div>
    </form>
</div>

@endsection
